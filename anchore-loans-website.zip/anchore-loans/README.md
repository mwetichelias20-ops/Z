
# Anchore Loans Website

A blue-and-white loan marketplace/lender prototype with:
- 40+ loan products
- illustrative 1.00%–4.50% promotional rates
- co-signer/guarantor badges with a prototype 650+ minimum
- sign-in and create-account flows
- 6-digit email activation codes via your domain SMTP
- floating applicant live chat
- agent live-chat console
- comprehensive loan application fields
- loan-specific dynamic fields for education, auto, home, business, and farm products

## Run locally
1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Enter your domain mailbox SMTP values in `.env`.
4. Run:
   `npm install`
   `npm start`
5. Open `http://localhost:3000`
6. Agent console: `http://localhost:3000/agent.html`

## Email activation codes
The code is sent using Nodemailer and the SMTP mailbox you configure. For example:
`MAIL_FROM=Anchore Loans <no-reply@anchoreloans.com>`

Your domain provider must allow SMTP, and SPF/DKIM/DMARC should be configured for reliable delivery.

## Production requirements
This is a functional starter/prototype, not a production lending platform. Before public launch:
- replace in-memory users/codes/applications with an encrypted database
- use server-side sessions/JWT with secure HttpOnly cookies
- encrypt sensitive data at rest and in transit
- never log SSNs, passwords, activation codes, bank credentials, or raw identity documents
- integrate secure object storage and malware scanning for uploads
- add authenticated agent/staff roles, MFA, audit logs, and access controls
- add CSRF protection and stricter CSP
- add KYC/identity-verification and credit-bureau integrations only under appropriate contracts and permissible-purpose rules
- add jurisdiction-specific licenses, disclosures, APR/fee calculations, E-SIGN consent, adverse-action workflow, privacy notice, accessibility, retention rules, and fair-lending controls
- obtain legal/compliance review for payday, student, mortgage, SBA, agricultural, and other regulated products
- do not auto-approve or deny using protected characteristics

## Rate disclaimer
The 1%–4.5% rates were requested as design values and are explicitly labeled illustrative. They should not be published as real or guaranteed APRs unless Anchore Loans can legally and actually offer those terms.
