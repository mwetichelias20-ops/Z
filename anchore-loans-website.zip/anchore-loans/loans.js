window.LOANS = [
  {
    "name": "Personal loan",
    "rate": 3.9,
    "cosigner": false
  },
  {
    "name": "Secured personal loan",
    "rate": 2.5,
    "cosigner": false
  },
  {
    "name": "Emergency loan",
    "rate": 4.5,
    "cosigner": false
  },
  {
    "name": "Installment loan",
    "rate": 4.2,
    "cosigner": false
  },
  {
    "name": "Student loan",
    "rate": 2.7,
    "cosigner": true
  },
  {
    "name": "Undergraduate student loan",
    "rate": 2.4,
    "cosigner": true
  },
  {
    "name": "Graduate student loan",
    "rate": 2.6,
    "cosigner": true
  },
  {
    "name": "Parent student loan",
    "rate": 3.0,
    "cosigner": false
  },
  {
    "name": "Student loan refinance",
    "rate": 2.3,
    "cosigner": true
  },
  {
    "name": "Auto loan",
    "rate": 3.4,
    "cosigner": false
  },
  {
    "name": "New car loan",
    "rate": 2.9,
    "cosigner": false
  },
  {
    "name": "Used car loan",
    "rate": 3.8,
    "cosigner": false
  },
  {
    "name": "Auto refinance loan",
    "rate": 3.3,
    "cosigner": false
  },
  {
    "name": "Lease buyout loan",
    "rate": 3.9,
    "cosigner": false
  },
  {
    "name": "Mortgage",
    "rate": 4.5,
    "cosigner": false
  },
  {
    "name": "Construction loan",
    "rate": 4.4,
    "cosigner": true
  },
  {
    "name": "Home equity loan",
    "rate": 3.5,
    "cosigner": false
  },
  {
    "name": "Business loan",
    "rate": 4.0,
    "cosigner": true
  },
  {
    "name": "SBA loan",
    "rate": 3.2,
    "cosigner": true
  },
  {
    "name": "Startup loan",
    "rate": 4.5,
    "cosigner": true
  },
  {
    "name": "Working capital loan",
    "rate": 4.1,
    "cosigner": true
  },
  {
    "name": "Equipment financing",
    "rate": 3.7,
    "cosigner": true
  },
  {
    "name": "Debt consolidation loan",
    "rate": 3.6,
    "cosigner": false
  },
  {
    "name": "Payday loan",
    "rate": 4.5,
    "cosigner": false
  },
  {
    "name": "Salary advance",
    "rate": 2.0,
    "cosigner": false
  },
  {
    "name": "Buy Now, Pay Later loan",
    "rate": 1.0,
    "cosigner": false
  },
  {
    "name": "Medical loan",
    "rate": 3.1,
    "cosigner": false
  },
  {
    "name": "Cosmetic procedure financing",
    "rate": 3.9,
    "cosigner": false
  },
  {
    "name": "Home improvement loan",
    "rate": 3.2,
    "cosigner": false
  },
  {
    "name": "Solar financing",
    "rate": 2.1,
    "cosigner": false
  },
  {
    "name": "Wedding loan",
    "rate": 4.2,
    "cosigner": false
  },
  {
    "name": "Vacation loan",
    "rate": 4.4,
    "cosigner": false
  },
  {
    "name": "Relocation loan",
    "rate": 3.8,
    "cosigner": false
  },
  {
    "name": "Adoption loan",
    "rate": 3.0,
    "cosigner": false
  },
  {
    "name": "Funeral loan",
    "rate": 3.7,
    "cosigner": false
  },
  {
    "name": "Agricultural loan",
    "rate": 3.1,
    "cosigner": true
  },
  {
    "name": "Farm operating loan",
    "rate": 3.5,
    "cosigner": true
  },
  {
    "name": "Farm equipment loan",
    "rate": 3.2,
    "cosigner": true
  },
  {
    "name": "Livestock loan",
    "rate": 3.8,
    "cosigner": true
  },
  {
    "name": "Mortgage refinance",
    "rate": 4.2,
    "cosigner": false
  },
  {
    "name": "Personal loan refinance",
    "rate": 3.6,
    "cosigner": false
  },
  {
    "name": "Business refinance loan",
    "rate": 3.9,
    "cosigner": true
  },
  {
    "name": "Savings-secured loan",
    "rate": 1.8,
    "cosigner": false
  }
];