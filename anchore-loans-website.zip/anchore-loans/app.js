
const API = location.protocol === 'file:' ? 'http://localhost:3000' : '';
function loanIcon(n){return ['⌂','⚡','◎','↗','★'][n.length%5]}
function renderLoans(){
 const grid=document.getElementById('loanGrid'); if(!grid || !window.LOANS)return;
 grid.innerHTML=LOANS.map((l,i)=>`<article class="loan-card"><div class="loan-top"><div class="loan-icon">${loanIcon(l.name)}</div><div class="rate">${l.rate.toFixed(2)}%*</div></div><h3>${l.name}</h3><div class="small">Illustrative promotional rate. Final APR and fees depend on underwriting and applicable law.</div>${l.cosigner?'<span class="pill">Co-signer/guarantor may be required • 650+ prototype minimum</span>':''}<ul class="requirements"><li>Identity & income verification</li><li>Ability-to-repay review</li><li>Credit and debt review where applicable</li></ul><div class="card-actions"><a class="btn btn-primary" href="auth.html?mode=create&loan=${encodeURIComponent(l.name)}">Apply now</a></div></article>`).join('');
}
function populateLoanSelect(){
 const s=document.getElementById('loanType'); if(!s||!window.LOANS)return;
 s.innerHTML='<option value="">Select a loan</option>'+LOANS.map(l=>`<option>${l.name}</option>`).join('');
 const q=new URLSearchParams(location.search).get('loan'); if(q)s.value=q;
 s.addEventListener('change',renderLoanSpecific); renderLoanSpecific();
}
function renderLoanSpecific(){
 const s=document.getElementById('loanType'), el=document.getElementById('loanSpecific'); if(!s||!el)return;
 const n=s.value.toLowerCase(); let html='';
 if(n.includes('student')) html=`<hr style="border:0;border-top:1px solid #e4edf9;margin:28px 0"><h2>Education details</h2><div class="form-grid"><div class="field"><label>School name</label><input name="school"></div><div class="field"><label>Program / degree</label><input name="program"></div><div class="field"><label>Enrollment status</label><select name="enrollment"><option>Full-time</option><option>Part-time</option><option>Graduated / refinance</option></select></div><div class="field"><label>Expected graduation</label><input name="graduation" type="month"></div><div class="field"><label>Estimated annual cost of attendance</label><input name="coa" type="number"></div><div class="field"><label>Financial aid received</label><input name="aid" type="number"></div></div>`;
 else if(n.includes('auto')||n.includes('car')||n.includes('lease')) html=`<hr style="border:0;border-top:1px solid #e4edf9;margin:28px 0"><h2>Vehicle details</h2><div class="form-grid"><div class="field"><label>Purchase price / payoff amount</label><input name="vehiclePrice" type="number"></div><div class="field"><label>Down payment</label><input name="downPayment" type="number"></div><div class="field"><label>Year</label><input name="vehicleYear"></div><div class="field"><label>Make / model</label><input name="vehicle"></div><div class="field"><label>VIN</label><input name="vin"></div><div class="field"><label>Mileage</label><input name="mileage" type="number"></div></div>`;
 else if(n.includes('mortgage')||n.includes('home equity')||n.includes('construction')||n.includes('home improvement')||n.includes('solar')) html=`<hr style="border:0;border-top:1px solid #e4edf9;margin:28px 0"><h2>Property details</h2><div class="form-grid"><div class="field full"><label>Property address</label><input name="propertyAddress"></div><div class="field"><label>Property type</label><select name="propertyType"><option>Primary residence</option><option>Second home</option><option>Investment property</option></select></div><div class="field"><label>Estimated property value</label><input name="propertyValue" type="number"></div><div class="field"><label>Current mortgage balance</label><input name="mortgageBalance" type="number"></div><div class="field"><label>Purchase price / project cost</label><input name="projectCost" type="number"></div></div>`;
 else if(n.includes('business')||n.includes('sba')||n.includes('startup')||n.includes('working capital')||n.includes('equipment')) html=`<hr style="border:0;border-top:1px solid #e4edf9;margin:28px 0"><h2>Business details</h2><div class="form-grid"><div class="field"><label>Legal business name</label><input name="businessName"></div><div class="field"><label>Entity type</label><select name="entityType"><option>LLC</option><option>Corporation</option><option>Partnership</option><option>Sole proprietorship</option><option>Nonprofit</option></select></div><div class="field"><label>EIN</label><input name="ein"></div><div class="field"><label>Years in business</label><input name="yearsBusiness"></div><div class="field"><label>Annual revenue</label><input name="revenue" type="number"></div><div class="field"><label>Average monthly deposits</label><input name="deposits" type="number"></div><div class="field full"><label>Use of proceeds</label><textarea name="businessPurpose"></textarea></div></div>`;
 else if(n.includes('farm')||n.includes('agricultural')||n.includes('livestock')) html=`<hr style="border:0;border-top:1px solid #e4edf9;margin:28px 0"><h2>Farm details</h2><div class="form-grid"><div class="field"><label>Farm / operation name</label><input name="farmName"></div><div class="field"><label>Acreage</label><input name="acreage" type="number"></div><div class="field"><label>Primary commodity / livestock</label><input name="commodity"></div><div class="field"><label>Annual farm revenue</label><input name="farmRevenue" type="number"></div><div class="field full"><label>Purpose of financing</label><textarea name="farmPurpose"></textarea></div></div>`;
 el.innerHTML=html;
}
function toggleChat(){const b=document.getElementById('chatBox');if(b)b.style.display=b.style.display==='block'?'none':'block'}
async function sendChat(){
 const input=document.getElementById('chatInput'), msgs=document.getElementById('chatMessages'); if(!input||!input.value.trim())return;
 const m=input.value.trim(); msgs.insertAdjacentHTML('beforeend',`<div class="msg me">${m.replace(/[<>]/g,'')}</div>`); input.value='';
 try{await fetch(API+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:m,name:localStorage.getItem('anchoreName')||'Website visitor'})});}
 catch(e){msgs.insertAdjacentHTML('beforeend','<div class="msg">Message saved locally. Live-agent server is not connected.</div>')}
}
let pendingEmail='';
function showAuth(mode){
 document.getElementById('signinForm')?.classList.toggle('hidden',mode!=='signin'); document.getElementById('createForm')?.classList.toggle('hidden',mode!=='create'); document.getElementById('verifyForm')?.classList.add('hidden');
 document.getElementById('signTab')?.classList.toggle('active',mode==='signin');document.getElementById('createTab')?.classList.toggle('active',mode==='create');
}
async function postJSON(path,data){const r=await fetch(API+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const j=await r.json();if(!r.ok)throw new Error(j.error||'Request failed');return j}
async function createAccount(e){
 e.preventDefault(); const email=document.getElementById('createEmail').value; pendingEmail=email;
 try{await postJSON('/api/register',{firstName:firstName.value,lastName:lastName.value,email,password:createPassword.value}); localStorage.setItem('anchoreName',firstName.value+' '+lastName.value); showVerify(email,'Activation code sent.');}
 catch(err){setStatus(err.message,'error')}
}
async function startSignin(e){
 e.preventDefault(); const email=document.getElementById('signinEmail').value; pendingEmail=email;
 try{await postJSON('/api/login',{email,password:signinPassword.value});showVerify(email,'Activation code sent.');}catch(err){setStatus(err.message,'error')}
}
function showVerify(email,msg){document.getElementById('signinForm')?.classList.add('hidden');document.getElementById('createForm')?.classList.add('hidden');document.getElementById('verifyForm')?.classList.remove('hidden');document.getElementById('verifyEmail').textContent=email;setStatus(msg,'success')}
async function verifyCode(e){e.preventDefault();try{await postJSON('/api/verify',{email:pendingEmail,code:otp.value});location.href='apply.html'+(new URLSearchParams(location.search).get('loan')?'?loan='+encodeURIComponent(new URLSearchParams(location.search).get('loan')):'')}catch(err){setStatus(err.message,'error')}}
async function resendCode(){try{await postJSON('/api/resend',{email:pendingEmail});setStatus('A new activation code was sent.','success')}catch(err){setStatus(err.message,'error')}}
function setStatus(m,c){const s=document.getElementById('authStatus');if(s)s.innerHTML=`<p class="${c}">${m}</p>`}
async function submitApplication(e){
 e.preventDefault(); const status=document.getElementById('applicationStatus'); const data=Object.fromEntries(new FormData(e.target).entries());
 delete data.ssn; delete data.idFile; delete data.incomeFile; delete data.bankFile; delete data.addressFile;
 try{const j=await postJSON('/api/applications',data);status.innerHTML=`<span class="success">Application received. Reference: ${j.reference}</span>`; e.target.scrollIntoView({behavior:'smooth'});}
 catch(err){status.innerHTML=`<span class="error">${err.message}. Start the Node server to enable submission.</span>`}
}
document.addEventListener('DOMContentLoaded',()=>{renderLoans();populateLoanSelect();const q=new URLSearchParams(location.search);if(q.get('mode')==='create')showAuth('create')});
